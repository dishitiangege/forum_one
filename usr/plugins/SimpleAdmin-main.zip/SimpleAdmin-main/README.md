![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112221239.jpg)
SimpleAdmin 是一款即插即用的typecho后台美化插件，gogobody修改自[小王先森](https://xwsir.cn) 的后台插件。

登录界面修改自泽泽站长（qqdie）的登录插件。

## 注意

上传插件后请改名为 SimpleAdmin ，否则启用不了

----

下载：

https://github.com/gogobody/SimpleAdmin/archive/main.zip


## 特色：
1. 插件，即插即用
2. 安全，不会破坏您的原有文件
3. 轻量级，几乎纯js,css修改
4. 支持 gogobody 原创的黑暗模式
5. 手机，pc 自适应
6. 界面绝对简洁！

## 预览：
登录：
![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112221021.png)

PC样式：

![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112210213.png)

深色模式：
![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210414162435.png)

![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112210542.png)

手机样式：
![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112220721.png)

![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112220807.png)

![](https://cdn.jsdelivr.net/gh/gogobody/blog-img/blogimg/20210112221800.png)